﻿using Microsoft.AspNetCore.Mvc;
using ProjetinhoEmpresa.Models;

namespace ProjetinhoEmpresa.Controllers
{
    public class UsesrController : Controller
    {
        public IActionResult Index()
        {
            var user = new List<User>
            {
                new User
                {
                   NomeCliente = "Rogin da Silva Melo",
                   EmailCliente = "rogerinLocao@hotmail.com.br",
                   EnderecoCliente = "Rua Alberto Grosso, 45",
                   CpfCliente = 58660128044,
                   TelCliente = "(41) 93588-4521",

                },
            };

            return View(user);
        }
    }
}
