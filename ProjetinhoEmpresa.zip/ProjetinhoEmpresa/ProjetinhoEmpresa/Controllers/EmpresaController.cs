﻿using Microsoft.AspNetCore.Mvc;
using ProjetinhoEmpresa.Models;

namespace ProjetinhoEmpresa.Controllers
{
    public class EmpresaController : Controller
    {
        public IActionResult Index()
        {
            var empresa = new List<Empresa>
            {
                new Empresa
                {
                    NomeEmpresa = "Real Dorogs",
                    EnderecoEmpresa = "Rua São Leooldo da Mandioca",
                    MargemDesconto = 10,
                    RegimeFiscal = "Sim",
                    Cnpj = 35445762000186
                },
            };

            return View(empresa);
        }
    }
}
