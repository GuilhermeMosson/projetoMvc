﻿using Microsoft.AspNetCore.Mvc;
using ProjetinhoEmpresa.Models;

namespace ProjetinhoEmpresa.Controllers
{
    public class EmpresaController : Controller
    {
        public IActionResult Index()
        {
            var empresa = new List<Empresa>
            {
                new Empresa
                {
                    NomeEmpresa = "Tech Selleres",
                    EnderecoEmpresa = "Rua São Leooldo da Mandioca",
                    MargemDesconto = 10,
                    RegimeFiscal = "Sim",
                    Cnpj = 35445762000186
                },
                new Empresa
                {
                    NomeEmpresa = "MegaTech Solutions",
                    EnderecoEmpresa = "Avenida das Tecnologias, 123",
                    MargemDesconto = 15,
                    RegimeFiscal = "Não",
                    Cnpj = 12345678000195

                },
                new Empresa
                {
                    NomeEmpresa = "FutureTech Ltda.",
                    EnderecoEmpresa = "Rua do Futuro, 321",
                    MargemDesconto = 12,
                    RegimeFiscal = "Não",
                    Cnpj = 55667788000190

                },
                new Empresa
                {
                    NomeEmpresa = "Digital Hub",
                    EnderecoEmpresa = "Praça dos Tecnólogos, 789",
                    MargemDesconto = 20,
                    RegimeFiscal = "Sim",
                    Cnpj = 11223344000188

                },
            };

            return View(empresa);
        }
    }
}
