﻿using Microsoft.AspNetCore.Mvc;
using ProjetinhoEmpresa.Models;

namespace ProjetinhoEmpresa.Controllers
{
    public class PedidoController : Controller
    {
        public IActionResult Index()
        {
            var pedidos = new List<Pedido>
            {
                new Pedido
                {
                    NomePedido = "Playstation 4",
                    Status = "Console da playstation",
                    DataEntrada = DateTime.Now,
                    Responsavel = "Jorge Amildo",
                    NomeCliente = "Rogerin",
                    EmailCliente = "rogerinLocao@hotmail.com.br"
                },
                new Pedido
                {
                    NomePedido = "Xbox Series X",
                    Status = "Console da Microsoft",
                    DataEntrada = DateTime.Now,
                    Responsavel = "Ana Costa",
                    NomeCliente = "Carlos Eduardo Silva",
                    EmailCliente = "carlos.silva@outlook.com"

                },
                new Pedido
                {
                    NomePedido = "PC Gamer",
                    Status = "Computador de alto desempenho",
                    DataEntrada = DateTime.Now,
                    Responsavel = "Pedro Henrique",
                    NomeCliente = "Juliana Santos Pereira",
                    EmailCliente = "juliana.santos@gmail.com"

                },
            };

            return View(pedidos);
        }
    }
}
