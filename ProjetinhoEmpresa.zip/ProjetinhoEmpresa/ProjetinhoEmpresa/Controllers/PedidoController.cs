﻿using Microsoft.AspNetCore.Mvc;
using ProjetinhoEmpresa.Models;

namespace ProjetinhoEmpresa.Controllers
{
    public class PedidoController : Controller
    {
        public IActionResult Index()
        {
            var pedidos = new List<Pedido>
            {
                new Pedido
                {
                    NomePedido = "Mercadoria Legal",
                    Status = "1 kg de uma mercadoria dentro da lei",
                    DataEntrada = DateTime.Now,
                    Responsavel = "Jorge Amildo Pintu",
                    NomeCliente = "Rogerin",
                    EmailCliente = "rogerinLocao@hotmail.com.br"
                },
            };

            return View(pedidos);
        }
    }
}
