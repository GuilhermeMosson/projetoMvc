﻿using Microsoft.AspNetCore.Mvc;
using ProjetinhoEmpresa.Models;

namespace ProjetinhoEmpresa.Controllers
{
    public class UserController : Controller
    {
        public IActionResult Index()
        {
            var user = new List<User>
            {
                new User
                {
                   NomeCliente = "Rogin da Silva Melo",
                   EmailCliente = "rogerinLocao@hotmail.com.br",
                   EnderecoCliente = "Rua Alberto Grosso, 45",
                   CpfCliente = 58660128044,
                   TelCliente = "(41) 93588-4521",

                },
                new User
                {
                    NomeCliente = "Carlos Eduardo Silva",
                    EmailCliente = "carlos.silva@outlook.com",
                    EnderecoCliente = "Rua das Palmeiras, 678",
                    CpfCliente = 98765432100,
                    TelCliente = "(21) 99876-5432"
                },
                new User
                {
                    NomeCliente = "Juliana Santos Pereira",
                    EmailCliente = "juliana.santos@gmail.com",
                    EnderecoCliente = "Praça Central, 987",
                    CpfCliente = 45678912300,
                    TelCliente = "(31) 91234-5678"
                },
                new User
                {
                    NomeCliente = "Fernando Almeida",
                    EmailCliente = "fernando.almeida@yahoo.com.br",
                    EnderecoCliente = "Rua dos Jacarandás, 234",
                    CpfCliente = 32165498700,
                    TelCliente = "(51) 93456-7890"
                },
            };

            return View(user);
        }
    }
}
