using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjetinhoEmpresa.Views.Users
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
