using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjetinhoEmpresa.Views.User
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
