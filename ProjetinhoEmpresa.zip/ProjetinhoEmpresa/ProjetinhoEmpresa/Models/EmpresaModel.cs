﻿namespace ProjetinhoEmpresa.Models
{
    public class Empresa
    {
        public string NomeEmpresa { get; set; } = string.Empty;
        public string EnderecoEmpresa { get; set; } = string.Empty;
        public int MargemDesconto { get; set; }
        public string RegimeFiscal { get; set; } = string.Empty;
        public double Cnpj { get; set; }
    }
}
