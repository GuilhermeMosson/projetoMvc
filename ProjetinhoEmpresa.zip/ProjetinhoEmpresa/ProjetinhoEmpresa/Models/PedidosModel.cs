﻿namespace ProjetinhoEmpresa.Models
{
    public class Pedido
    {
        public string NomePedido { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public DateTime DataEntrada { get; set; }
        public string Responsavel { get; set; } = string.Empty;
        public string NomeCliente { get; set; } = string.Empty;
        public string EmailCliente { get; set; } = string.Empty;

    }
}
