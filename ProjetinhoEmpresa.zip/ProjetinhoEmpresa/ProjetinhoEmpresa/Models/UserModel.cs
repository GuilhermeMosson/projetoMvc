﻿using System.Security.Principal;

namespace ProjetinhoEmpresa.Models
{
    public class User
    {
        public string NomeCliente { get; set; } = string.Empty;
        public string EmailCliente { get; set; } = string.Empty;
        public string EnderecoCliente { get; set; } = string.Empty;
        public double CpfCliente { get; set; }
        public string TelCliente { get; set; } = string.Empty;
    }
}
