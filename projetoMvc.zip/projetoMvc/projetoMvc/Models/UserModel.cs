﻿namespace projetoMvc.Models
{
    public class Users
    {
        public int IdUser { get; set; }
        public string NomeUser { get; set; } = string.Empty;
        public string EmailUser { get; set; } = string.Empty;

    }
}
