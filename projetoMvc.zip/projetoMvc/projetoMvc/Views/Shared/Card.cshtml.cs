using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace projetoMvc.Views.Shared
{
    public class CardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
