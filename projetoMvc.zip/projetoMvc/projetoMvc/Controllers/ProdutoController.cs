﻿using Microsoft.AspNetCore.Mvc;
using projetoMvc.Models;

namespace projetoMvc.Controllers
{
    public class ProdutoController : Controller
    {
        public IActionResult Index()
        {
            var produtos = new List<Produto>
            {
                new Produto
                {
                    Id = 1,
                    Nome = "Xbox 360",
                    Valor = 1699.99m,
                    Proprietario = "Jorge dos Santos",
                    Desc = "Melhor console de TODOS, sem dúvida",
                    DataLancamento = new DateTime(2010, 03, 25, 16, 45, 21)
                },

                new Produto
                {
                    Id = 2,
                    Nome = "Nintendo 3DS",
                    Valor = 499.99m,
                    Proprietario = "Renato Amado",
                    Desc = "Console portátio da Ninteto, BRABO",
                    DataLancamento = new DateTime(2011, 07, 14, 12, 29, 01)
                },

                new Produto
                {
                    Id = 3,
                    Nome = "Playstation 3",
                    Valor = 899.5m,
                    Proprietario = "Souza Aragão",
                    Desc = "Console plastation 3",
                    DataLancamento = new DateTime(2008, 01, 28, 10, 31, 58)
                }

            };
            return View(produtos);
        }
    }
}
