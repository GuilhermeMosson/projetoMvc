using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjetoMensagem01.Views.Mensagem
{
    public class MensagemModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
