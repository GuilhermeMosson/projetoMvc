﻿using Microsoft.AspNetCore.Mvc;
using ProjetoMensagem01.Models;

namespace ProjetoMensagem01.Controllers
{
    public class MensagemController : Controller
    {
        public IActionResult Index()
        {
            var mensagem = new List<Mensagem>
            {
                new Mensagem
                {
                    NomeContato = "Jorge Aragão da Silva",
                    ConteudoMensagem = "Ola mundao",
                    DataEnvio = DateTime.Now
                },
            };
            return View(mensagem);
        }
    }
}

