﻿using Microsoft.AspNetCore.Mvc;
using ProjetoMensagem01.Models;

namespace ProjetoMensagem01.Controllers
{
    public class MensagemController : Controller
    {
        public IActionResult Index()
        {
            mensagem = List<Mensagem>
            {
                Nome
            } 
            return View();
        }
    }
}
