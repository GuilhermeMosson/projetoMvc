﻿using System.Security.Cryptography;

namespace ProjetoMensagem01.Models
{
    public class Mensagem
    {
        public string NomeContato { get; set; } = string.Empty;
        public string ConteudoMensagem { get; set; } = string.Empty;
        public DateTime DataEnvio { get; set; }
    }
}
